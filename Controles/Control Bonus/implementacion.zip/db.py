''' 
This is our database
It manages the relations, queries and data
It checks that the relations are of correct type
'''

from pageNew import *
from relation import *

# The relation dictionary indexed by relation name
Relations = {}

# This is what 'CREATE TABLE R(a int, b int, c text)' does here attributes = ['a','b','c'], types = ['int','int','str']
# buff is the buffer that the table has access to; this is set to be the one used by the database
def create_table(rName, attributes, types):
    # Creates a relation with rName, and attributes as its attributes with respective types

    # First we check that the relation does not exist
    if (rName in Relations.keys()):
        print('Relation already exists')
        return False

    Rel = Relation(rName, attributes, types)
    Relations[rName] = Rel

    # If all went well e return True
    return True

# This is what 'SELECT * FROM R' does
def all_tuples(R):
    R = Relations[R]

    iterR = relIter(R)
    iterR.open()

    t = iterR.next()
    while t:
        print(t)
        t = iterR.next()
 
    iterR.close()

# This is what 'SELECT * FROM R WHERE a = x' does
def filtered_tuples(R,cond):
    # Here cond is just a single attribute equality
    # cond is if the form 'attr = value'

    R = Relations[R]
    iterR = relIter(R) # this is the only object you can use to obtain tuples from R

    pass


# This is 'SELECT R.a, R.b, ... FROM R'
def projected_tuples(R,projAttribs):
    # projAttribs is a list of attributes of R
    # You should check that all is good with respect to used attributes

    R = Relations[R]
    iterR = relIter(R) # this is the only object you can use to obtain tuples from R

    pass

def cross(R, S):
    # Performs the cross product of the two relations
    # Assumes that R is not equal to S, otherwise it will not work properly -- for bonus, implement iterators properly

    R = Relations[R]
    S = Relations[S]

    iterR = relIter(R)
    iterS = relIter(S)

    # these iters allow you to get the needed tuples

    pass

# SELECT * FROM R,S WHERE ( R.a = S.b AND R.c = S.d AND ...)
def nested_loop_join(R,S,join):
    # Performs a join on the condition join
    # join = [(attribR,attribS), (attribR,attribS), ...]
    # where attribR is an attribute in R and same for attribS with S
    # assume that no pairs are repeated
    # You have to check if the attributes are well specified

    R = Relations[R]
    S = Relations[S]

    iterR = relIter(R)
    iterS = relIter(S)
    # You can access tuples in R and S only via iterR and iterS

    pass




# Test cases:

#create_table('R',['a','b'],['int','int'])

#create_table('S',['b','c'],['int','int'])

#cross('R','R')

#all_tuples('R')

#all_tuples('S')

#filtered_tuples('R','a = 1')

#nested_loop_join('R','S','b')



# insert_tuple
'''
create_table('X',['a','b','c'],['int','int','str'])

X = Relations['X']

X.insert_tuple('1 1 hola')
X.insert_tuple('1 2 chao')
X.insert_tuple('2 1 hola')
X.insert_tuple('2 2 chao')
X.insert_tuple('3 1 hola')
X.insert_tuple('3 2 chao')
'''