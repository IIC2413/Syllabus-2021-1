from pageNew import *
from os import path

class Relation:
	# The constructor
	def __init__(self, rName, aNames, aTypes):
		if not(len(aNames) == len(aTypes)):
			print('Relation definition error')
			return

		self.rName = rName # Relation name
		self.attributes = aNames # Names of our attributes; this should be a list
		self.types = aTypes # Type of each attribute; for now we support only int and text, where text can not have spaces
		self.numAttrib = len(self.attributes) # number of attributes
		self.root_page = self.rName + '-1' # Name of the Root page = relationName-1 (e.g. for R R-1)
		# When we create  relation, we set the current page to equal the root page
		# We make sure that the root page exists (if not we create it)
		self.create_root()

	def create_root(self):
		# We create the root page if it does not exist already (not to have inconsistencies later)
		# That is, when we create a relation, we always create at least the root page if it is not already on disk

		# Need to deal with this
		if not(path.exists(self.root_page)):
			 f = open(self.root_page, "x")
			 root = Page(self.root_page)
			 root.write_page()
			 f.close()

	def get_attribute_types(self):
		# Returns a dictionary of attribute name: attribute type
		# E.g. if we have R(a int, b str), it will return {'a':'int','b':'str'}

		res = {}

		for i in range(self.numAttrib):
			res[self.attributes[i]] = self.types[i]

		return res

	def get_individual_values(self, tup):
		# When tup is a tuple of values read from disk it is a single string (e.g. '1 Hello 7')
		# when the relation has a signature R(a int, b text, c int), we want to get the individual values
		# this mathod takes a sting '1 Hello 7' for R(a int, b text, c int) and returns a dictionary:
		#	{'a':1, 'b':Hello, 'c':7}; as before, for simplicity strings can not have spaces
		# we assume that the values are well typed

		res = {}

		vals = tup.split(' ')
		for i in range(self.numAttrib):
			attrib = self.attributes[i]
			if (self.types[i] == 'int'):
				res[attrib] = int(vals[i])
			else:
				res[attrib] = vals[i]

		return res

	def insert_tuple(self, tup):
		# Inserts the tuple tup into an empty position in some page of the relation
		# If all pages are full, a new page is created and linked to the previous one
		# If the tuple is already in the relation nothing is done

		pass


# This is the iterator class for a relation
# Note that if we embedd this into the class itself, we can not open the relation R twice at the same time; like this it works
# This will allos to have as many iterators for the same relation as we want
class relIter:
	# The constructor
	def __init__(self, Rel):
		self.relation = Rel #this is an instance of a relation we are iterating over

		# The iterator logic (nested in the relation itself; this is just a simplification, and not how you would really do it)
		self.opened_page = None # The page we have loaded in main memory
		self.current_page = None # The page we are currently on;
		self.current_pos = None # Current position on the current_page; before opening None


	def open(self):
		# Resets the cursor to the beginning

		# Load the root into memory
		self.opened_page = Page(self.relation.root_page)
		self.opened_page.read_from_disk()

		# set the bookkeepnt variables
		self.current_page = self.relation.root_page
		self.current_pos = -1


	def has_next(self):
		# returns true if there is a next tuple
		# It also positions the "pointers" self.current_page and self.current_tuple over the next tuple
		# That is, it will advance the self.current_page and self.current_pos to the one with the next tuple

		if not(self.current_page):
			print('Iterator is closed')
			return False

		# We need to advance by one first and do all the checks (we consumed the last tuple in next())
		self.current_pos += 1

		# If we came to the end, we need to move onto the next page; 4 should be changed by PAGE_SIZE constant
		if self.current_pos == 5:
			# Get the page we are working with
			page = self.opened_page
			next_page = page.next
			if next_page == '<NULL>':
				# We came to an end
				return False
			else:
				# If not, we obtain the next page name
				self.current_page = next_page
				# Set the position to zero
				self.current_pos = 0
				# Open the next page
				#self.opened_page.close()
				self.opened_page = Page(self.current_page)
				self.opened_page.read_from_disk()

		# Now we roll
		pos = self.current_pos

		# If the page position is empty, we call has_next again recursively:
		if self.opened_page.get_element_from_page(pos) == '<EMPTY>':
			return self.has_next()
		
		return True

	def next(self):
		# returns the next tuple if it exists

		if (self.has_next()):
			return self.opened_page.get_element_from_page(self.current_pos)

		return None

	def close(self):
		# Closes the iterator
		self.current_page = None
		self.current_pos = None


		



'''
R = Relation('R',['a','b'],['int','int'])

iterR = relIter(R)

iterR.open()

t = iterR.next()

while t:
	print(t)
	t = iterR.next()

iterR.close()


R.insert_tuple('14 12')
'''